package com.anita.medicinetime;



public interface BasePresenter {

    void start();
}
