package com.anita.medicinetime.alarm;

import com.anita.medicinetime.BasePresenter;
import com.anita.medicinetime.BaseView;
import com.anita.medicinetime.data.source.History;
import com.anita.medicinetime.data.source.MedicineAlarm;


public interface ReminderContract {

    interface View extends BaseView<Presenter> {

        void showMedicine(MedicineAlarm medicineAlarm);

        void showNoData();

        boolean isActive();

        void onFinish();

    }

    interface Presenter extends BasePresenter {

        void finishActivity();

        void onStart(long id);

        void loadMedicineById(long id);

        void addPillsToHistory(History history);

    }
}
