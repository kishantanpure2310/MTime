package com.anita.medicinetime;

import android.content.Context;
import androidx.annotation.NonNull;


import com.anita.medicinetime.data.source.MedicineRepository;
import com.anita.medicinetime.data.source.local.MedicinesLocalDataSource;



public class Injection {

    public static MedicineRepository provideMedicineRepository(@NonNull Context context) {
        return MedicineRepository.getInstance(MedicinesLocalDataSource.getInstance(context));
    }
}